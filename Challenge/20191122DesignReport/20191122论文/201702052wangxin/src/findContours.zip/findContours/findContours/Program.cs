﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenCvSharp;
using OpenCvSharp.Extensions;
namespace OpenCvSharp_03
{
    class Program
    {

        static void Main(string[] args)
        {

            Mat srcImage = Cv2.ImRead(@"C:\Users\Thinkpad x260\source\repos\findContours\findContours\bin\Debug\1.jpg");
            Mat dst_Image = MyFindContours(srcImage);
            Cv2.ImShow("srcImage:", srcImage);
            Cv2.ImShow("contours", dst_Image);
            Cv2.WaitKey();

        }
        public static Mat MyFindContours(Mat srcImage)
        {
            //转化为灰度图
            Mat src_gray = new Mat();
            Cv2.CvtColor(srcImage, src_gray, ColorConversionCodes.RGB2GRAY);

            //滤波
            Cv2.Blur(src_gray, src_gray, new Size(3, 3));

            //Canny边缘检测
            Mat canny_Image = new Mat();
            Cv2.Canny(src_gray, canny_Image, 100, 200);

            //获得轮廓
            Point[][] contours;
            HierarchyIndex[] hierarchly;
            Cv2.FindContours(canny_Image, out contours, out hierarchly, RetrievalModes.Tree, ContourApproximationModes.ApproxSimple, new Point(0, 0));

            //将结果画出并返回结果
            Mat dst_Image = Mat.Zeros(canny_Image.Size(), srcImage.Type());
            Random rnd = new Random();
            for (int i = 0; i < contours.Length; i++)
            {
                Scalar color = new Scalar(rnd.Next(0, 255), rnd.Next(0, 255), rnd.Next(0, 255));
                Cv2.DrawContours(dst_Image, contours, i, color, 2, LineTypes.Link8, hierarchly);
            }
            return dst_Image;
        }
    }
}

