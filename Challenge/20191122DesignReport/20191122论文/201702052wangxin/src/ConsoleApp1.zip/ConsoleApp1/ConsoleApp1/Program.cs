﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenCvSharp;  //引用

namespace CvCam
{
    class Program
    {
        static VideoCapture cap = new VideoCapture();

        static void Main(string[] args)
        {
            CamFunc_00();
            // CamFunc_01();
        }

        static void CamFunc_00()                     //固定背景对比,获取第一帧背景，启动后，摄像头的位置不能动
        {
            Mat bgMat = new Mat();
            Mat capMat = new Mat();

            bool isFirstFrame = true;                //判断是不是第一帧

            cap.Open(0);                             //打开摄像头
            if (!cap.IsOpened()) return;             //判断摄像头是否已经打开

            while (true)                           //逐帧获取摄像头画面
            {
                capMat = cap.RetrieveMat();      //获取摄像头画面
                if (capMat.Empty()) continue;
                //   Cv2.CvtColor(capMat, capMat, ColorConversionCodes.BGR2GRAY);   //转成灰度图
                if (isFirstFrame)
                {
                    isFirstFrame = false;
                    bgMat = capMat;
                }

                for (int i = 0; i < capMat.Rows; i += 10)
                {
                    for (int j = 0; j < capMat.Cols; j += 10)
                    {
                        ，
                        if (Math.Abs(capMat.Get<Vec3b>(i, j).Item0 - bgMat.Get<Vec3b>(i, j).Item0) > 50 || Math.Abs(capMat.Get<Vec3b>(i, j).Item1 - bgMat.Get<Vec3b>(i, j).Item1) > 50 || Math.Abs(capMat.Get<Vec3b>(i, j).Item2 - bgMat.Get<Vec3b>(i, j).Item2) > 50)
                        {
                            Cv2.Circle(capMat, new Point(j, i), 2, Scalar.White, 4); //画圆，在capMat的(j,i)位置画半径为2，厚度为4的白色的实心圆
                        }
                    }
                }

                Cv2.ImShow("CamFunc_00", capMat);  //显示
                Cv2.WaitKey(20);
            }
        }

        static void CamFunc_01()     //前后两帧对比，此时物体需要一直移动才能被检测出
        {
            Mat lastMat = new Mat();
            Mat capMat = new Mat();

            bool isEvenFrame = true;           //判断是不是偶数帧，即为参照帧    

            cap.Open(0);                             //打开摄像头
            if (!cap.IsOpened()) return;             //判断摄像头是否已经打开

            while (true)                           //逐帧获取摄像头画面
            {
                capMat = cap.RetrieveMat();           //获取摄像头画面
                if (capMat.Empty()) continue;
                //   Cv2.CvtColor(capMat, capMat, ColorConversionCodes.BGR2GRAY);   //转成灰度图
                if (isEvenFrame)
                {
                    isEvenFrame = false;
                    lastMat = capMat;
                }

                else
                {
                    for (int i = 0; i < capMat.Rows; i += 10)   //遍历capMat所有像素
                    {
                        for (int j = 0; j < capMat.Cols; j += 10)
                        {
                            //这样写不知道有没有什么问题，但是能实现效果，先就这样写,获取像素点的rgb值做对比，其中50是差值，可根据自己需求来调节
                            if (Math.Abs(capMat.Get<Vec3b>(i, j).Item0 - lastMat.Get<Vec3b>(i, j).Item0) > 50 || Math.Abs(capMat.Get<Vec3b>(i, j).Item1 - lastMat.Get<Vec3b>(i, j).Item1) > 50 || Math.Abs(capMat.Get<Vec3b>(i, j).Item2 - lastMat.Get<Vec3b>(i, j).Item2) > 50)
                            {
                                Cv2.Circle(capMat, new Point(j, i), 2, Scalar.White, 4); //画圆，在capMat的(j,i)位置画半径为2，厚度为4的白色的实心圆
                            }
                        }
                    }
                    isEvenFrame = true;
                }
                Cv2.ImShow("CamFunc_01", capMat); //显示
                Cv2.WaitKey(20);

            }
        }
    }
}